TEST 2026-11-28: full_bilingual_top, but for speech-balloon lines (NPC / field talk above heads) the Japanese box is at the BOTTOM (the bottom box is not shown during balloon talk). Normal box lines keep it at the top.

Voices and tables: unchanged (use the full version's). On the handheld: keep your current script_en somewhere else, delete it in the game folder, copy script_versions/test_balloon_top/script_en in. To go back: put your old script_en back.
