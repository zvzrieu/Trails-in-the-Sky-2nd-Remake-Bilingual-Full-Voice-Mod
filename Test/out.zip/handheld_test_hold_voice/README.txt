TEST 2026-11-28: full_bilingual (bottom popup), but in cinematics that advance by themselves the Japanese box ends with a pause as long as that line's voice, so it should stay up while the voice plays (10,522 lines).

Voices and tables: unchanged (use the full version's). On the handheld: keep your current script_en somewhere else, delete it in the game folder, copy script_versions/test_hold_voice/script_en in. To go back: put your old script_en back.

What to check: the Japanese box now stays until the voice ends; the scene does not wait longer than before (no long pause between lines); the next line's box appears normally.
