Plain scripts 2026-11-19 07:05: script_en + the two table folders.
  - no * mark in front of lines with a generated voice
  - no Schera/Agate route lines in-game (no inserted other-route lines, no route notes); the route reader still has them
  - bottom-bar remarks: where Schera and Agate have a line saying the same thing, only the partner in your party
    speaks (as in the original game); all other remarks still play for every member

559 script files + 4 table files
