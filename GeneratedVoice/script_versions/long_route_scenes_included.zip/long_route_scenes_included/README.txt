Route scenes 2026-11-19 06:39: script_en only. In the 84 places that showed
"[... Route] N lines differ here (different staging). Route reader: R...." the other partner's lines now play
right after that note, as plain text boxes (with voice where one exists), over your own route's staging.
Everything else is the same as the normal build. Voices and tables are unchanged, so nothing else is needed.

script_versions\  pick ONE: scenes_bilingual_bottom / scenes_bilingual_top / scenes_english

559 files
